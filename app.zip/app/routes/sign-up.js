import Ember from 'ember';

export default Ember.Route.extend({
  beforeModel() {
      if (this.get('session.isAuthenticated')) {
        this.transitionTo('dashboard');
      }
    },
    actions: {
      error(error, transition) {
          //console.log(error);
          //this.controllerFor('sign-up').displayError(error.message);
      }
    }
});
