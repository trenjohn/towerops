import Ember from 'ember';

export default Ember.Route.extend({
  firebaseApp: Ember.inject.service(),
  //welcomeName: Ember.inject.service(),

  model() {

    },
    actions: {
    accessDenied() {
      if (this.get('session.isAuthenticated')) {
        this.transitionTo('dashboard');
      } else {
        this.transitionTo('index');
      }
    }
  }
});


// const uid = this.get('firebaseApp').auth().currentUser.uid;
// return this.store.query('profile', {orderBy: 'uid', equalTo: uid}).then((users) => {
//     const user = users.get('firstObject');
//     var name = user.get('firstName');
//     this.set('userName', name);
//   });
//console.log(userName);
