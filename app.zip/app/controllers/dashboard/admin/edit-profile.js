import Ember from 'ember';

export default Ember.Controller.extend({
  firebaseApp: Ember.inject.service(),

  actions: {
    editProfile: function() {

      const uid = this.get('firebaseApp').auth().currentUser.uid;
      const firstName = this.get('firstName');
      const lastName = this.get('lastName');

      this.store.query('profiles', {orderBy: 'uid', equalTo: uid}).then((profile) => {
        const profile = profile.get('firstObject');
        const id = profile.get('id');
        console.log(profile);
        console.log(id);

      this.store.findRecord('profile', id).then(function(profileToUpdate) {
        profileToUpdate.set('firstName', firstName);
        profileToUpdate.set('lastName', lastName);
        profileToUpdate.save().then(console.log(profileToUpdate));
        }).catch((error)=>{
          console.log(error);
        });
      });
    }
  }
});
