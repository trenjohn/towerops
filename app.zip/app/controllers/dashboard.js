import Ember from 'ember';

export default Ember.Controller.extend({

  // userPermission: Ember.inject.service(),
  // compute() {
  //   let userPermission = this.get('userPermission');
  //   const userRole = userPermission.getRole();
  //   //console.log(userRole);
  // }
  //
  // //let userPermission = this.get('userPermission')
  // // userRole: Ember.Object.extend({
  // //   isAdmin: false,
  // //   isExec: false
  // // }),
  // //   if (userPermission.getRole() > 11) {
  // //       this.set('isAdmin', true);
  // //     }
  // // })
  // // compute() {
  // //   let userPermission = this.get('userPermission');
  // //   if (userPermission.getRole() > 11) {
  // //     record.set('isAdmin', true);
  // //   }
  // // //   if (userPermission.getRole() > 15) {
  // // //     return true;
  // // //   } else {
  // // //     return false;
  // // //   }
  // //  }

});
