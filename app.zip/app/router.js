import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('sign-in');
  //this.authenticatedRoute('dashboard');
  this.route('sign-up');
  this.route('sign-out');
  this.authenticatedRoute('personnel');
  this.authenticatedRoute('jobsites');

  this.authenticatedRoute('dashboard', function() {
    this.route('foreman', function() {
      this.route('weekly-submissions');
      this.route('manpower');
    });
    this.authenticatedRoute('office', function() {
      this.route('weeklysubmissions');
      this.route('manpower');
    });
    this.authenticatedRoute('admin', function() {
      this.route('create-profile');
      this.route('edit-profile');
      this.route('weeklysubmissions');
    });
  });
});

export default Router;
